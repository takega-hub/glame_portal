# GLAME AI Video & Reels System

## 1. Назначение

AI-видео для GLAME нужно создавать как fashion-content, а не как случайную анимацию.

Цели:

- привлечь внимание;
- показать украшение в движении;
- создать желание примерить;
- усилить Instagram/TikTok;
- делать красивые кампании без постоянных съёмок;
- создавать viral/social-native форматы без потери премиальности.

## 2. Почему видео лучше делать через keyframes

Прямое AI-видео часто портит:

- лицо;
- руки;
- украшения;
- одежду;
- форму товара;
- детали металла;
- стабильность образа.

Правильный pipeline:

```text
идея → сценарий → keyframes → генерация фото → выбор кадров → image-to-video → монтаж → overlay/text → музыка → финальная проверка
```

## 3. Базовая структура 15 секунд

```text
0–2 сек — hook / визуальный удар
2–5 сек — macro detail: металл, камень, рука, ткань
5–9 сек — модель / образ / styling
9–13 сек — full look / transformation
13–15 сек — CTA
```

## 4. Типы GLAME Reels

### 4.1. Product desire ad

Цель: захотеть конкретное украшение.

Структура:

- hook;
- macro detail;
- украшение на модели;
- полный образ;
- CTA.

### 4.2. Fashion transformation

До/после:

- образ без украшения;
- момент надевания;
- образ с акцентом;
- финальный look.

Hook:

> “Образу не хватало одного акцента.”

### 4.3. Stylist advice

Польза + стиль:

- что выбрать к платью;
- какие серьги к открытым плечам;
- как не перегрузить свадебный образ;
- золото к загару;
- жемчуг без возрастности.

### 4.4. 3 looks / 1 accent

Один товар в трёх образах:

- everyday;
- evening;
- event/wedding.

### 4.5. Gift emotion

Подарочный сценарий:

- коробка;
- рука открывает;
- украшение крупно;
- модель надевает;
- emotion/CTA.

### 4.6. Boutique mood

Атмосфера GLAME:

- зеркало;
- примерка;
- продавец/стилист;
- свет бутика;
- украшения крупно.

## 5. Вирусные hooks для GLAME

- “Украшение, которое меняет весь образ.”
- “Когда платье простое, но детали говорят за тебя.”
- “Один акцент — и образ выглядит собранным.”
- “Что надеть к открытому вырезу?”
- “Серьги, которые красиво работают на фото.”
- “До/после: образ без украшений и с GLAME.”
- “Если не хочется перегружать образ, начните с этого.”
- “Тот самый акцент для вечера.”
- “Жемчуг, который не выглядит возрастным.”
- “Золото + загар: летняя формула GLAME.”
- “3 образа с одними серьгами.”
- “Подарок, который выглядит личным.”

## 6. Storyboard template

```text
Название ролика:
Цель:
Товар / категория:
Формат:
Длительность:

Сцена 1 — 0–2 сек
Visual:
Motion:
Text overlay:

Сцена 2 — 2–5 сек
Visual:
Motion:
Text overlay:

Сцена 3 — 5–9 сек
Visual:
Motion:
Text overlay:

Сцена 4 — 9–13 сек
Visual:
Motion:
Text overlay:

Сцена 5 — 13–15 сек
Visual:
Motion:
CTA:
```

## 7. Motion primitives

Хорошие движения для украшений:

- slow camera push-in;
- subtle head turn;
- hand puts on ring;
- hand closes bracelet clasp;
- light sliding over metal;
- silk fabric movement;
- earrings moving slightly;
- model turns to mirror;
- gift box opening;
- close-up sparkle transition;
- boutique mirror reflection.

Избегать:

- резких random movements;
- деформации лица;
- “плавающих” украшений;
- смены одежды между кадрами;
- смены лица модели;
- чрезмерного сияния.

## 8. Prompt pack для image-to-video

### Keyframe image prompt

```text
Premium GLAME fashion editorial keyframe, elegant woman wearing [jewelry], [clothing], [location], [lighting], [camera], realistic jewelry details, natural skin texture, high-end fashion campaign quality.
```

### Video motion prompt

```text
Slow cinematic camera push-in, subtle natural movement, soft light gliding over the jewelry, model makes a gentle head turn, earrings catch the light, elegant restrained fashion motion, realistic, no deformation.
```

### Negative video prompt

```text
face morphing, changing jewelry, distorted hands, extra fingers, flickering, warped metal, floating earrings, changing clothes, unstable face, plastic skin, low quality, text, watermark
```

## 9. Пример Reels: украшение меняет образ

```text
Название:
Украшение, которое меняет весь образ

Цель:
Показать серьги как главный акцент простого вечернего образа.

Сцена 1 — 0–2 сек
Visual: модель в чёрном платье без украшений, нейтральный фон.
Motion: slow push-in.
Text: “Образу не хватает акцента?”

Сцена 2 — 2–5 сек
Visual: крупно золотые серьги на шёлковой ткани.
Motion: light slides over metal.
Text: “Добавьте деталь у лица”

Сцена 3 — 5–9 сек
Visual: модель надевает серьги.
Motion: gentle hand movement.
Text: “Серьги собирают образ”

Сцена 4 — 9–13 сек
Visual: полный look, серьги у лица, уверенный взгляд.
Motion: subtle head turn.
Text: “И делают его вечерним”

Сцена 5 — 13–15 сек
Visual: GLAME mood frame / boutique / close-up.
CTA: “Примерьте в GLAME”
```

## 10. Монтаж

Рекомендации:

- вертикальный формат 9:16;
- короткие сцены 1.5–3 сек;
- текст не вшивать в AI-изображение, добавлять в монтаже;
- музыка: fashion/elegant/modern;
- переходы мягкие;
- не перегружать эффектами;
- в конце понятный CTA.

## 11. Проверка финального видео

- украшение не меняется между кадрами;
- лицо модели стабильно;
- руки не искажены;
- одежда не “плывёт”;
- визуал выглядит дорого;
- hook понятен за 2 секунды;
- CTA есть;
- нет дешёвой viral-подачи;
- ролик можно показать от лица GLAME.
