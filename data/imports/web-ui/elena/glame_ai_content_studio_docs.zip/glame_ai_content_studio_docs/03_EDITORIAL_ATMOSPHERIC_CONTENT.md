# GLAME Editorial & Atmospheric AI Content

## 1. Назначение

Атмосферный AI-контент нужен, чтобы продавать не только украшение, а **образ, настроение и желание быть в стиле GLAME**.

Он используется для:

- Instagram posts;
- Stories;
- Reels keyframes;
- Tilda/site hero;
- приложения;
- campaign moodboards;
- свадебных/выпускных/вечерних подборок;
- visual branding.

## 2. Чем отличается от каталога

Каталог отвечает на вопрос:

> “Как выглядит товар?”

Editorial отвечает на вопрос:

> “Как я буду выглядеть и чувствовать себя с этим украшением?”

## 3. Состав полного образа

Каждый atmospheric visual должен описывать:

1. Модель.
2. Макияж.
3. Волосы.
4. Одежду.
5. Украшения.
6. Позу.
7. Свет.
8. Фон/локацию.
9. Камеру/кадр.
10. Настроение.
11. Коммерческий смысл.

## 4. Модель

Параметры для промпта:

- возрастной диапазон;
- типаж;
- выражение лица;
- волосы;
- макияж;
- кожа;
- поза;
- энергия.

Примеры:

```text
elegant woman, natural beauty, soft makeup, clean skin texture, calm confident expression, hair slicked back
```

```text
modern feminine model, minimal makeup, slightly wet hair, refined facial features, quiet luxury mood
```

## 5. Одежда

Одежда должна усиливать украшение.

### Базовые варианты GLAME

- white shirt;
- black minimal dress;
- silk slip dress;
- satin bridal dress;
- beige knit top;
- linen resort suit;
- black tailored blazer;
- ivory evening top;
- open shoulder dress;
- strapless dress.

## 6. Украшения

Нужно описывать:

- тип: серьги, колье, кольца, браслеты;
- металл: gold, silver, mixed metal;
- форма: drops, flowers, sculptural, chains, pearls;
- масштаб: delicate, medium, statement;
- цвет: clear stones, colored inserts, pearl white;
- роль: main accent, soft detail, evening shine.

## 7. Свет

Хороший свет делает AI-визуал дорогим.

Варианты:

- soft studio lighting;
- diffused daylight;
- side light;
- golden hour;
- low contrast editorial light;
- clean beauty light;
- subtle jewelry highlights.

Избегать:

- harsh flash;
- сильных бликов;
- грязных теней;
- пересвета кожи;
- цветного клубного света без задачи.

## 8. Фон / локация

### Studio

- neutral beige background;
- ivory backdrop;
- graphite wall;
- silk fabric;
- marble/stone surface;
- mirror reflection.

### Boutique

- elegant jewelry boutique;
- fitting mirror;
- soft interior light;
- premium retail atmosphere.

### Resort / Crimea mood

- subtle Black Sea resort elegance;
- warm evening light;
- stone terrace;
- sea breeze mood;
- no tourist cliché.

### Wedding

- bridal morning;
- satin dress;
- soft white room;
- pearl details;
- clean romantic light.

## 9. Камера и кадр

Фразы для реализма:

- high-end fashion photography;
- editorial portrait;
- 85mm lens;
- shallow depth of field;
- macro jewelry detail;
- close-up portrait;
- half-body shot;
- clean composition;
- negative space for text;
- realistic skin texture.

## 10. Основные editorial-сценарии GLAME

### 10.1. Everyday premium

Украшения как деталь повседневного образа.

Одежда: рубашка, жакет, knit top.  
Украшения: цепи, серьги, кольца.  
Настроение: calm, polished, expensive everyday.

### 10.2. Evening accent

Украшение как главный вечерний акцент.

Одежда: чёрное платье, открытые плечи.  
Украшения: statement earrings, колье, браслет.  
Настроение: confident, evening, elegant.

### 10.3. Wedding / bridal

Украшение как нежный, фото-ready акцент.

Одежда: satin/ivory dress.  
Украшения: pearls, drops, crystals.  
Настроение: soft, romantic, modern bridal.

### 10.4. Graduation

Юность, праздник, фото, без перегруза.

Одежда: light dress, minimal dress, pastel/white.  
Украшения: earrings near face, delicate shine.  
Настроение: fresh, festive, young, elegant.

### 10.5. Resort GLAME

Лето, загар, золото, открытая кожа.

Одежда: linen, silk, white, beige.  
Украшения: gold chains, bracelets, rings.  
Настроение: warm, relaxed, premium resort.

### 10.6. Gift story

Украшение как эмоция подарка.

Объекты: коробка, руки, лента, карточка.  
Настроение: intimate, warm, premium.

## 11. Шаблон editorial prompt

```text
Premium fashion editorial image for GLAME jewelry brand.
[Model description], wearing [clothing description], styled with [jewelry description].
The jewelry is the main refined accent of the look.
[Location/background].
[Lighting].
[Camera/framing].
Mood: elegant, feminine, modern, premium, refined, realistic.
Natural skin texture, tasteful styling, high-end fashion campaign quality.
```

Negative:

```text
cheap marketplace style, Wildberries style, plastic skin, overretouched face, bad anatomy, extra fingers, distorted hands, deformed jewelry, melted metal, fake sparkle, cluttered background, text, watermark, logo, blurry, oversaturated, vulgar luxury
```

## 12. Пример

```text
Premium fashion editorial portrait for GLAME jewelry brand.
Elegant woman with slicked back hair, natural soft makeup, calm confident expression, wearing a minimal black off-shoulder dress and sculptural gold drop earrings.
The earrings are the main accent near the face, clearly visible, refined and realistic.
Neutral graphite studio background, soft side studio lighting with subtle highlights on gold metal.
Close-up portrait, 85mm lens, shallow depth of field, high-end fashion campaign quality.
Mood: modern, feminine, expensive, restrained, elegant.
```

## 13. Что проверять

- образ цельный;
- украшение видно;
- одежда подходит украшению;
- свет дорогой;
- модель не выглядит пластиковой;
- нет лишних украшений;
- нет дешёвого глянца;
- это похоже на GLAME;
- понятно, где использовать: сайт, пост, stories, Reels keyframe.
