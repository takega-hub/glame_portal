# GLAME AI Content Production Workflow & Learning Plan

## 1. Production workflow

Общий процесс создания AI-контента:

```text
1. Задача
2. Тип контента
3. Товар / тема / кампания
4. Референсы
5. Промпт
6. Генерация вариантов
7. Отбор
8. Проверка качества
9. Доработка
10. Утверждение
11. Адаптация под канал
12. Публикация
13. Сохранение промпта и результата
```

## 2. Brief template

```text
Название задачи:
Тип контента: catalog / editorial / video / story / banner
Цель:
Канал:
Формат:
Товар / категория:
Артикул, если есть:
Клиентский сценарий:
Настроение:
Референсы:
Что обязательно показать:
Что нельзя:
Срок:
Кто утверждает:
```

## 3. Один товар → content pack

Из одного товара можно сделать 10–15 единиц контента.

### Catalog pack

1. Product clean visual.
2. On-model visual.
3. Macro detail.
4. Scale reference.
5. Set/cross-sell image.

### Social pack

6. Fashion portrait.
7. Stories new-in.
8. “How to wear” post.
9. Gift visual.
10. Reels keyframes.

### Campaign pack

11. Tilda/site banner.
12. App/home block visual.
13. CRM visual.
14. Wedding/graduation visual, if relevant.
15. Video/Reels concept.

## 4. Одна коллекция → campaign pack

Для коллекции/темы:

1. Campaign concept.
2. Moodboard.
3. 12 key visuals.
4. 3 Reels concepts.
5. 5 Stories.
6. Tilda block.
7. App banner.
8. CRM visual.
9. Captions.
10. CTA pack.

## 5. Naming and storage

Рекомендуемая структура хранения:

```text
/content-studio/
  /products/
    /ARTICLE/
      references/
      generated/
      approved/
      prompts.md
      quality_review.md
  /campaigns/
    /2026-06-summer-trends/
      moodboard/
      keyframes/
      reels/
      captions.md
      prompts.md
  /prompt-library/
  /visual-bible/
```

## 6. Learning plan for Elena / team

### Модуль 1. Основы AI-контента

Цель: понимать, из чего состоит качественный AI-визуал.

Темы:

- типы AI-контента;
- отличие catalog/editorial/video;
- reference image;
- prompt;
- negative prompt;
- почему AI искажает украшения;
- как проверять качество.

Практика:

- взять 3 визуала и разобрать: можно публиковать или нет.

### Модуль 2. Каталожный контент

Темы:

- product passport;
- точность украшения;
- on-model;
- macro;
- руки/уши/шея;
- checklist.

Практика:

- выбрать 1 товар и подготовить catalog prompt.

### Модуль 3. Fashion/editorial image

Темы:

- модель;
- одежда;
- макияж;
- поза;
- свет;
- фон;
- камера;
- цельный образ.

Практика:

- один товар → 3 образа: everyday, evening, wedding/resort.

### Модуль 4. Промпты

Темы:

- prompt constructor;
- prompt refinement;
- negative prompts;
- variants;
- как исправлять ошибки.

Практика:

- написать 5 промптов под разные сценарии.

### Модуль 5. Видео

Темы:

- hook;
- storyboard;
- keyframes;
- image-to-video;
- motion prompts;
- монтаж;
- CTA.

Практика:

- сделать storyboard 15-секундного Reels.

### Модуль 6. Вирусный контент

Темы:

- social-native hooks;
- “до/после”;
- “3 образа”;
- “ошибка/решение”;
- fashion transformation;
- как не уйти в дешевизну.

Практика:

- 10 hooks для одной категории украшений.

### Модуль 7. Production system

Темы:

- как один товар превращать в content pack;
- как хранить промпты;
- как вести библиотеку удачных решений;
- как утверждать и публиковать.

Практика:

- собрать mini content pack на один товар.

## 7. Первый практический спринт

Рекомендуемый старт:

```text
Спринт: 1 товар → 3 визуальных направления → 1 Reels concept
```

Шаги:

1. Выбрать реальное украшение GLAME.
2. Собрать product passport.
3. Подготовить reference image.
4. Создать catalog prompt.
5. Создать editorial prompt.
6. Создать social/viral prompt.
7. Сгенерировать 3–5 вариантов каждого направления.
8. Проверить по checklist.
9. Выбрать лучший visual direction.
10. Написать Reels storyboard.
11. Подготовить video motion prompts.

## 8. Метрики успеха

AI-контент успешен, если:

- Елена визуально утверждает направление;
- украшение читается;
- контент можно использовать в реальном канале;
- команда может повторить процесс;
- промпт сохранён;
- результат не выглядит как случайный AI;
- появляется контент, который ускоряет сайт/Instagram/CRM/приложение.

## 9. Следующий шаг

После создания документов нужно выбрать первый тестовый товар GLAME и пройти полный процесс:

```text
товар → промпты → генерация → разбор → улучшение → Reels concept
```
