# GLAME Prompt Constructor & Prompt Library

## 1. Главный принцип промпта

Для GLAME нельзя писать просто:

```text
красивая девушка в украшениях
```

Нужно писать как fashion-директор:

```text
какая девушка → какая одежда → какое украшение → какая поза → какой свет → какой фон → какая камера → какое настроение → какой формат → что нельзя
```

## 2. Базовый конструктор

```text
Тип контента:
Цель:
Канал:
Формат:
Украшение:
Точность товара нужна: да/нет
Модель:
Волосы:
Макияж:
Одежда:
Поза:
Локация/фон:
Свет:
Камера/кадр:
Настроение:
Коммерческий смысл:
Что нельзя:
```

## 3. Universal image prompt

```text
Premium fashion editorial image for GLAME jewelry brand.
[MODEL], wearing [CLOTHING], styled with [JEWELRY].
The jewelry is [ROLE: main accent / delicate detail / evening shine / bridal accent].
[LOCATION/BACKGROUND].
[LIGHTING].
[CAMERA/FRAMING].
Mood: [MOOD WORDS].
Realistic skin texture, refined styling, high-end jewelry campaign quality, clean composition.
```

Negative:

```text
cheap marketplace photo, Wildberries style, plastic skin, overretouched, bad anatomy, extra fingers, fused fingers, distorted hands, deformed jewelry, melted metal, fake sparkle, cluttered background, text, watermark, logo, blurry, noisy, oversaturated, vulgar luxury
```

## 4. Каталожный on-model prompt

```text
Realistic premium catalog lifestyle image for GLAME.
Use the provided reference jewelry accurately.
Elegant female model wearing the exact referenced [JEWELRY TYPE], same metal color, same shape, same stones, same proportions.
Clean studio background, soft diffused light, natural skin texture, high-end jewelry photography, sharp jewelry details.
The jewelry must be clearly visible and not altered.
No extra jewelry unless specified.
```

## 5. Studio portrait prompt

```text
Premium GLAME studio portrait, elegant woman with [HAIR], [MAKEUP], wearing [CLOTHING] and [JEWELRY].
The jewelry is clearly visible near the face and works as the main refined accent.
Neutral [beige/ivory/graphite] studio background, soft side studio lighting, realistic skin texture, high-end fashion photography, 85mm lens, shallow depth of field, clean composition.
Mood: modern, feminine, expensive, restrained, elegant.
```

## 6. Hands / rings / bracelet prompt

```text
GLAME jewelry close-up, elegant female hands wearing [RINGS/BRACELET], premium nude manicure, refined jewelry details, soft natural window light, warm beige background, realistic skin texture, graceful hand pose, high-end jewelry editorial photography, clean composition.
```

Negative:

```text
extra fingers, missing fingers, fused fingers, broken fingers, deformed hands, unrealistic nails, distorted ring, melted jewelry, cheap jewelry, low quality, blurry, watermark, text, harsh shadows, oversaturated
```

## 7. Earrings / face prompt

```text
Premium close-up portrait for GLAME, elegant woman wearing [EARRINGS], hair [UP/SLICKED BACK/TUCKED BEHIND EAR] so the earrings are clearly visible, soft makeup, natural skin texture, refined expression.
[BACKGROUND], [LIGHTING], close-up portrait, 85mm lens, shallow depth of field, high-end fashion campaign quality.
The earrings are realistic, symmetrical, sharp, and the main accent near the face.
```

## 8. Necklace / neckline prompt

```text
Premium GLAME jewelry editorial, close-up of neckline and decollete, elegant woman wearing [NECKLACE/CHAIN/PENDANT], [CLOTHING WITH NECKLINE], soft studio lighting, realistic skin texture, refined fabric, sharp jewelry details, clean luxury composition.
```

## 9. Bridal prompt

```text
Modern bridal jewelry editorial for GLAME, elegant bride in ivory satin dress, soft natural makeup, clean hair styling, wearing [PEARL/DROP/CRYSTAL JEWELRY].
Soft white room, diffused morning light, gentle romantic mood, high-end bridal fashion photography, realistic skin, refined jewelry sparkle, no overload, one main accent.
```

## 10. Graduation prompt

```text
Fresh elegant graduation jewelry editorial for GLAME, young woman in [LIGHT/MINIMAL/PASTEL] dress, wearing delicate [EARRINGS/NECKLACE], festive but not overloaded, soft studio light, clean background, youthful refined mood, photo-ready styling, realistic skin texture, premium fashion photography.
```

## 11. Resort prompt

```text
Premium GLAME resort jewelry campaign, elegant woman in white linen/silk summer outfit, warm golden hour light, delicate gold jewelry, bracelets and rings visible, subtle Black Sea Mediterranean resort mood, refined coastline atmosphere, natural beauty, high-end fashion editorial, warm neutral palette, sophisticated and feminine.
```

## 12. Gift prompt

```text
Premium GLAME gift jewelry visual, elegant hands opening a refined jewelry box with [JEWELRY], soft beige silk fabric, warm intimate light, tasteful luxury, clean composition, emotional gift moment, high-end product photography, no text, no logo unless provided.
```

## 13. Video motion prompt templates

### Slow luxury

```text
Slow cinematic camera push-in, soft light gliding over jewelry, subtle natural movement, elegant restrained fashion mood, realistic, stable face, stable jewelry, no deformation.
```

### Jewelry macro

```text
Macro camera movement across the jewelry surface, delicate sparkle, light reflection on gold/silver metal, shallow depth of field, luxurious slow motion, realistic details.
```

### Model turn

```text
The model gently turns her head, earrings catch the light, hair moves subtly, elegant calm expression, premium fashion editorial motion, stable face and jewelry.
```

### Hand action

```text
Elegant hand slowly puts on the ring/bracelet, natural fingers, refined movement, jewelry remains sharp and realistic, soft studio light, luxury product motion.
```

## 14. Prompt quality rules

Хороший промпт:

- конкретный;
- описывает одежду;
- описывает украшение;
- задаёт свет;
- задаёт камеру;
- задаёт настроение;
- содержит ограничения;
- содержит negative prompt.

Плохой промпт:

- “красивая девушка”;
- “дорого-богато”;
- “сделай красиво”;
- без одежды;
- без света;
- без формата;
- без указания украшения;
- без negative prompt.
